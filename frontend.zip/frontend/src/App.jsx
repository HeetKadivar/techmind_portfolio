import './App.css'
import './index.css'
import MainRoutes from './Routes/MainRoutes'

function App() {

  return (
    <>
 
  <MainRoutes/>
  </>
)
}

export default App;

